#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray, String
from urdf_parser_py.urdf import URDF

class ArmImpedance(Node):
    def __init__(self):
        super().__init__('arm_impedance')
        self.declare_parameter('robot_description', '')
        self.declare_parameter('cmd_topic', '/wbc/arm_cmd')
        self.declare_parameter('rate_hz', 50.0)

        xml = self.get_parameter('robot_description').value
        if not xml:
            raise RuntimeError("arm_impedance_node: 'robot_description' is empty.")
        # >>>>>>> KEY FIX: pass bytes, not unicode with XML header
        self.robot = URDF.from_xml_string(xml.encode('utf-8'))

        out_topic = self.get_parameter('cmd_topic').value
        self.pub_cmd   = self.create_publisher(Float64MultiArray, out_topic, 10)
        self.pub_state = self.create_publisher(String, '/arm/state', 10)
        self.timer = self.create_timer(1.0/float(self.get_parameter('rate_hz').value), self.on_timer)

        # safe default hold pose: [j1..j6, grip]
        self.q = [0.0, -0.6, 1.2, 0.0, 0.6, 0.0, 0.0]
        self.get_logger().info(f"Arm impedance online. Publishing joint targets to {out_topic}")

    def on_timer(self):
        m = Float64MultiArray(); m.data = self.q
        self.pub_cmd.publish(m)
        self.pub_state.publish(String(data="hold"))

def main():
    rclpy.init(); rclpy.spin(ArmImpedance()); rclpy.shutdown()
if __name__ == '__main__':
    main()
