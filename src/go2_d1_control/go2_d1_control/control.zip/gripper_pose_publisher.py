import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
import numpy as np

# Fix old packages that still reference np.float (NumPy>=1.20)
if not hasattr(np, 'float'):
    np.float = float  # noqa: E305

try:
    from urdf_parser_py.urdf import URDF
    from kdl_parser_py.urdf import treeFromUrdfModel
    import PyKDL as kdl
    HAVE_KDL = True
except Exception:
    HAVE_KDL = False

class GripperPosePublisher(Node):
    def __init__(self):
        super().__init__('gripper_pose_publisher')
        # Declare params with safe defaults
        self.declare_parameter('robot_description', '')
        self.declare_parameter('base_link', 'base_link')
        self.declare_parameter('gripper_link', 'gripper_link')
        self.base_link = self.get_parameter('base_link').get_parameter_value().string_value
        self.tip_link  = self.get_parameter('gripper_link').get_parameter_value().string_value

        self.pub = self.create_publisher(PoseStamped, '/arm/gripper_pose', 10)
        self.state_pub = self.create_publisher(String, '/arm/state', 10)

        self.timer = self.create_timer(0.02, self.tick)  # 50 Hz

        self.kdl_ok = False
        self.joint_names = []
        self.q = None

        xml = self.get_parameter('robot_description').get_parameter_value().string_value or ''
        if xml and HAVE_KDL:
            try:
                # URDF parser may choke on unicode decl; give it bytes
                robot = URDF.from_xml_string(xml.encode('utf-8'))
                ok, tree = treeFromUrdfModel(robot)
                if ok:
                    chain = tree.getChain(self.base_link, self.tip_link)
                    self.joint_names = [robot.joint_map[j.name].name
                                        for j in robot.joints
                                        if robot.joint_map[j.name].type != 'fixed']
                    self.chain      = chain
                    self.fk_solver  = kdl.ChainFkSolverPos_recursive(chain)
                    self.kdl_ok = True
                    self.state_pub.publish(String(data='gripper_pose: KDL mode'))
                    self.get_logger().info(f'KDL OK: {self.base_link} -> {self.tip_link}')
                else:
                    self.state_pub.publish(String(data='gripper_pose: KDL chain failed'))
            except Exception as e:
                self.get_logger().warn(f'URDF/KDL init failed: {e}')
                self.state_pub.publish(String(data='gripper_pose: TF-only mode'))
        else:
            if not HAVE_KDL:
                self.get_logger().warn('kdl_parser_py / PyKDL not available; TF-only mode.')
            else:
                self.get_logger().warn('robot_description empty; TF-only mode.')
            self.state_pub.publish(String(data='gripper_pose: TF-only mode'))

        # Optional: subscribe joint_states if you have it later
        # self.create_subscription(JointState, '/joint_states', self.js_cb, 10)

    def tick(self):
        # For now we just publish an identity pose in base_link if FK isn’t available.
        # That keeps consumers from crashing and proves the topic exists.
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.base_link
        msg.pose.orientation.w = 1.0
        if self.kdl_ok and self.q is not None:
            # If you start providing joint_states later, place FK here.
            pass
        self.pub.publish(msg)

def main():
    rclpy.init()
    rclpy.spin(GripperPosePublisher())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
