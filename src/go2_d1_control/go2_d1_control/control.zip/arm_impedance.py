import rclpy, numpy as np, time
from rclpy.node import Node
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseStamped, Twist
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from urdf_parser_py.urdf import URDF
from kdl_parser_py.urdf import treeFromUrdfModel
import PyKDL as kdl
import tf2_ros
import tf_transformations

def rot_to_quat(R):
    T = np.eye(4); T[:3,:3] = R
    q = tf_transformations.quaternion_from_matrix(T)
    return q

def skew(v):
    return np.array([[0,-v[2],v[1]], [v[2],0,-v[0]], [-v[1],v[0],0]])

class ArmImpedance(Node):
    def __init__(self):
        super().__init__('arm_impedance')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('ee_link', 'Link6')
        self.declare_parameter('joints', ['Joint1','Joint2','Joint3','Joint4','Joint5','Joint6'])
        self.declare_parameter('K_xyz', [1200.0, 1200.0, 1500.0])
        self.declare_parameter('D_xyz', [40.0, 40.0, 50.0])
        self.declare_parameter('K_ang', [30.0, 30.0, 30.0])
        self.declare_parameter('D_ang', [2.0, 2.0, 2.0])
        self.declare_parameter('max_cart_vel', 0.15)
        self.declare_parameter('max_joint_vel', 0.8)
        self.declare_parameter('target_topic', '/ee_target')
        self.declare_parameter('arm_controller_name', '/arm_controller')

        self.base = self.get_parameter('base_frame').value
        self.ee = self.get_parameter('ee_link').value
        self.joint_names = list(self.get_parameter('joints').value)

        self.Kt = np.diag(self.get_parameter('K_xyz').value + self.get_parameter('K_ang').value)
        self.Dt = np.diag(self.get_parameter('D_xyz').value + self.get_parameter('D_ang').value)
        self.max_cart_vel = float(self.get_parameter('max_cart_vel').value)
        self.max_joint_vel = float(self.get_parameter('max_joint_vel').value)

        # Parse URDF and build KDL chain
        robot = URDF.from_parameter_server(key='robot_description')
        ok, tree = treeFromUrdfModel(robot)
        if not ok:
            raise RuntimeError('Failed to parse URDF to KDL tree')
        self.chain = tree.getChain(self.base, self.ee)
        self.nq = self.chain.getNrOfJoints()

        # KDL solvers
        self.fk_solver = kdl.ChainFkSolverPos_recursive(self.chain)
        self.jac_solver = kdl.ChainJntToJacSolver(self.chain)

        # State
        self.q = np.zeros(self.nq)
        self.dq = np.zeros(self.nq)
        self.q_received = False

        # Subscribers / publishers
        self.create_subscription(JointState, '/joint_states', self.on_jstate, 10)
        self.create_subscription(PoseStamped, self.get_parameter('target_topic').value, self.on_target, 10)
        self.pub_cmd = self.create_publisher(JointTrajectory, self.get_parameter('arm_controller_name').value + '/joint_trajectory', 10)

        # Timer for control loop
        self.last = self.get_clock().now()

    def on_jstate(self, msg: JointState):
        # Map incoming joint states to our arm joints
        name_to_pos = dict(zip(msg.name, msg.position))
        name_to_vel = dict(zip(msg.name, msg.velocity)) if msg.velocity else {}
        for i, jn in enumerate(self.joint_names):
            if jn in name_to_pos:
                self.q[i] = name_to_pos[jn]
                self.dq[i] = name_to_vel.get(jn, 0.0)
        self.q_received = True

    def fk(self, qvec):
        # Compute FK pose (position + quaternion) and 6D twist J
        qk = kdl.JntArray(self.nq)
        for i,v in enumerate(qvec): qk[i] = v
        frame = kdl.Frame()
        self.fk_solver.JntToFrame(qk, frame)
        p = np.array([frame.p[0], frame.p[1], frame.p[2]])
        R = np.array([[frame.M[0,0], frame.M[0,1], frame.M[0,2]],
                      [frame.M[1,0], frame.M[1,1], frame.M[1,2]],
                      [frame.M[2,0], frame.M[2,1], frame.M[2,2]]])
        J = kdl.Jacobian(self.nq)
        self.jac_solver.JntToJac(qk, J)
        Jnp = np.zeros((6,self.nq))
        for r in range(6):
            for c in range(self.nq):
                Jnp[r,c] = J[r,c]
        return p, R, Jnp

    def on_target(self, msg: PoseStamped):
        if not self.q_received:
            self.get_logger().warn('Waiting for /joint_states...')
            return
        # Desired pose
        pd = np.array([msg.pose.position.x, msg.pose.position.y, msg.pose.position.z])
        qd = np.array([msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w])
        Rd = tf_transformations.quaternion_matrix(qd)[:3,:3]

        # Current pose
        p, R, J = self.fk(self.q)

        # Compute pose error in spatial frame
        dp = pd - p
        # Orientation error (log map): R_err = Rd * R^T, rotvec = vee(log(R_err))
        R_err = Rd @ R.T
        angle = np.arccos(np.clip((np.trace(R_err)-1)/2.0, -1.0, 1.0))
        if abs(angle) < 1e-6:
            rotvec = np.zeros(3)
        else:
            w_hat = (R_err - R_err.T)/(2*np.sin(angle)) * angle
            rotvec = np.array([w_hat[2,1], w_hat[0,2], w_hat[1,0]])

        xerr = np.hstack([dp, rotvec])

        # Desired twist (impedance: v = K*e - D*J*dq)
        twist_des = self.Kt @ xerr - self.Dt @ (J @ self.dq)

        # Limit cartesian velocity
        v_norm = np.linalg.norm(twist_des[:3])
        if v_norm > self.max_cart_vel:
            twist_des[:3] *= self.max_cart_vel / (v_norm + 1e-9)

        # Joint velocity via damped least-squares
        lam = 0.02
        JT = J.T
        qdot = JT @ np.linalg.inv(J @ JT + (lam**2)*np.eye(6)) @ twist_des

        # Limit joint velocities
        for i in range(len(qdot)):
            qdot[i] = np.clip(qdot[i], -self.max_joint_vel, self.max_joint_vel)

        # Integrate small step
        dt = 1.0/200.0
        q_next = self.q + qdot * dt

        # Send as a short trajectory (1 point, 50ms)
        traj = JointTrajectory()
        traj.joint_names = self.joint_names
        pnt = JointTrajectoryPoint()
        pnt.positions = [float(v) for v in q_next]
        pnt.time_from_start.sec = 0
        pnt.time_from_start.nanosec = int(dt*1e9)
        traj.points = [pnt]
        self.pub_cmd.publish(traj)

def main():
    rclpy.init()
    rclpy.spin(ArmImpedance())
    rclpy.shutdown()
