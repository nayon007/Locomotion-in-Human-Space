import rclpy, numpy as np
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from visualization_msgs.msg import Marker
import tf2_ros

FOOT_LINKS = ['FL_foot','FR_foot','RL_foot','RR_foot']

class WBCBalance(Node):
    def __init__(self):
        super().__init__('wbc_balance')
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.pub_com = self.create_publisher(Marker, '/wbc/com_marker', 10)
        self.pub_poly = self.create_publisher(Marker, '/wbc/support_polygon', 10)
        self.timer = self.create_timer(0.05, self.on_timer)

    def on_timer(self):
        try:
            feet = []
            for fl in FOOT_LINKS:
                t = self.tf_buffer.lookup_transform('base_link', fl, rclpy.time.Time())
                feet.append(np.array([t.transform.translation.x, t.transform.translation.y]))
        except Exception as e:
            return
        feet = np.array(feet)  # 4x2
        # Convex hull for quad is just order them roughly
        # Here we assume order: FL(+y), FR(-y), RR(-y), RL(+y)
        # Publish polygon
        poly = Marker()
        poly.header.frame_id = 'base_link'
        poly.type = Marker.LINE_STRIP
        poly.scale.x = 0.01
        poly.color.a = 0.8; poly.color.b = 1.0
        for p in [feet[0], feet[1], feet[3], feet[2], feet[0]]:
            from geometry_msgs.msg import Point
            pt = Point(); pt.x, pt.y, pt.z = float(p[0]), float(p[1]), 0.0
            poly.points.append(pt)
        self.pub_poly.publish(poly)

        # Very rough COM proxy: base_link origin slightly forward
        com = Marker()
        com.header.frame_id = 'base_link'
        com.type = Marker.SPHERE
        com.scale.x = 0.05; com.scale.y = 0.05; com.scale.z = 0.05
        com.color.a = 0.9; com.color.g = 1.0
        com.pose.position.x = 0.02; com.pose.position.y = 0.0; com.pose.position.z = 0.0
        self.pub_com.publish(com)

def main():
    rclpy.init()
    rclpy.spin(WBCBalance())
    rclpy.shutdown()
