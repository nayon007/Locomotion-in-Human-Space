#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from unitree_api.msg import Request as UnitreeRequest
from std_srvs.srv import Trigger

class GripperController(Node):
    def __init__(self):
        super().__init__("gripper_controller")
        self.declare_parameter("open_api", 3001)
        self.declare_parameter("close_api", 3002)
        self.declare_parameter("open_param", "{}")
        self.declare_parameter("close_param", "{}")
        self.pub = self.create_publisher(UnitreeRequest, "/api/programming_actuator/request", 10)
        self.srv_open = self.create_service(Trigger, "~open", self.do_open)
        self.srv_close= self.create_service(Trigger, "~close", self.do_close)

    def send(self, api, param):
        m = UnitreeRequest(); m.header.identity.api_id = int(api); m.parameter = param
        self.pub.publish(m)

    def do_open(self, req, resp):
        self.send(self.get_parameter("open_api").value, self.get_parameter("open_param").value)
        resp.success, resp.message = True, "open sent"; return resp
    def do_close(self, req, resp):
        self.send(self.get_parameter("close_api").value, self.get_parameter("close_param").value)
        resp.success, resp.message = True, "close sent"; return resp

def main():
    rclpy.init(); rclpy.spin(GripperController()); rclpy.shutdown()
if __name__=="__main__": main()
