#!/usr/bin/env python3
import math, json, re, time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Bool
from urdf_parser_py.urdf import URDF
import PyKDL as kdl
from kdl_parser_py.urdf import treeFromUrdfModel
from unitree_arm.msg import ArmString

def clamp(v, lo, hi): return max(lo, min(hi, v))
def rad2deg(x): return x * 180.0 / math.pi

class ArmBottleReacher(Node):
    """
    Subscribes:
      - /perception/bottle_pose_base (PoseStamped in base frame)
      - /approach/ready (Bool)  # latch/unlatch
    Publishes:
      - /arm_Command (unitree_arm/ArmString, JSON funcode:2, mode:1) @ ~rate_hz
    """

    def __init__(self):
        super().__init__('arm_bottle_reacher')

        # Parameters
        self.declare_parameter('robot_description', '')
        self.declare_parameter('base_frame', 'base')       # <- matches your URDF
        self.declare_parameter('ee_frame',   'Link6')      # <- tip link name
        self.declare_parameter('reach_offset_x', 0.10)
        self.declare_parameter('reach_offset_z', 0.03)
        self.declare_parameter('min_x', 0.25)
        self.declare_parameter('max_x', 0.70)
        self.declare_parameter('min_z', 0.10)
        self.declare_parameter('max_z', 0.90)
        self.declare_parameter('y_limit', 0.25)
        self.declare_parameter('rate_hz', 30.0)
        self.declare_parameter('fresh_ms', 300.0)
        self.declare_parameter('gripper_deg', 0.0)

        self.base_frame = self.get_parameter('base_frame').value
        self.ee_frame   = self.get_parameter('ee_frame').value
        self.reach_offset_x = float(self.get_parameter('reach_offset_x').value)
        self.reach_offset_z = float(self.get_parameter('reach_offset_z').value)
        self.min_x  = float(self.get_parameter('min_x').value)
        self.max_x  = float(self.get_parameter('max_x').value)
        self.min_z  = float(self.get_parameter('min_z').value)
        self.max_z  = float(self.get_parameter('max_z').value)
        self.y_lim  = float(self.get_parameter('y_limit').value)
        self.rate_hz= float(self.get_parameter('rate_hz').value)
        self.fresh_ms = float(self.get_parameter('fresh_ms').value)
        self.grip_deg = float(self.get_parameter('gripper_deg').value)

        # URDF → KDL chain
        urdf_xml = self.get_parameter('robot_description').get_parameter_value().string_value
        self.chain = None
        self.nj = 0
        if urdf_xml:
            try:
                # Handle XML declaration in unicode strings
                cleaned = re.sub(r'^\s*<\?xml[^>]*\?>', '', urdf_xml)
                robot = URDF.from_xml_string(cleaned)
                ok, tree = treeFromUrdfModel(robot)
                if ok:
                    self.chain = tree.getChain(self.base_frame, self.ee_frame)
                    self.nj = self.chain.getNrOfJoints()
                    if self.nj == 0:
                        self.get_logger().error(
                            f"KDL chain has 0 joints between '{self.base_frame}' and '{self.ee_frame}'. "
                            "Check link names in the URDF or parameters."
                        )
                        self.chain = None
                    else:
                        self.fk  = kdl.ChainFkSolverPos_recursive(self.chain)
                        self.ik  = kdl.ChainIkSolverPos_LMA(self.chain)
                        self.q_seed = kdl.JntArray(self.nj)
                        for i in range(self.nj): self.q_seed[i] = 0.0
                        self.get_logger().info(f"KDL OK: {self.base_frame} -> {self.ee_frame} (joints={self.nj})")
                else:
                    self.get_logger().error("KDL tree build failed.")
            except Exception as e:
                self.get_logger().error(f"URDF/KDL parse failed: {e}")

        # State
        self.bottle: PoseStamped | None = None
        self.bottle_time_ns = 0
        self.locked: bool = False
        self.locked_pose: PoseStamped | None = None
        self._last_warn_time = 0.0

        # Subs
        self.sub_pose  = self.create_subscription(PoseStamped, '/perception/bottle_pose_base', self.on_bottle, 10)
        self.sub_ready = self.create_subscription(Bool, '/approach/ready', self.on_ready, 10)

        # Publisher (BEST_EFFORT, depth=1) for Unitree bridge compatibility
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.pub = self.create_publisher(ArmString, '/arm_Command', qos)

        self.timer = self.create_timer(max(1e-3, 1.0 / self.rate_hz), self.loop)

    # Callbacks
    def on_bottle(self, ps: PoseStamped):
        self.bottle = ps
        self.bottle_time_ns = self.get_clock().now().nanoseconds
        if not self.locked:
            self.locked_pose = ps

    def on_ready(self, msg: Bool):
        if msg.data and not self.locked and self.locked_pose is not None:
            self.locked = True
            self.get_logger().info("Bottle pose LOCKED for arm reach.")
        elif not msg.data and self.locked:
            self.locked = False
            self.get_logger().info("Bottle pose UNLOCKED; tracking live pose.")

    # IK helpers
    def goal_frame(self, x, y, z):
        return kdl.Frame(kdl.Rotation.RPY(0.0, 0.0, 0.0), kdl.Vector(x, y, z))

    def ik_solve(self, goal: kdl.Frame):
        if self.chain is None:
            return None
        q0 = kdl.JntArray(self.nj)
        for i in range(self.nj):
            q0[i] = float(self.q_seed[i])
        q = kdl.JntArray(self.nj)
        rc = self.ik.CartToJnt(q0, goal, q)
        if rc >= 0:
            for i in range(self.nj):
                self.q_seed[i] = q[i]
            return [q[i] for i in range(self.nj)]
        return None

    def _warn_throttled(self, msg: str, period_s: float = 1.0):
        now = time.time()
        if now - self._last_warn_time >= period_s:
            self._last_warn_time = now
            self.get_logger().warning(msg)

    def loop(self):
        # Pick source pose
        src = self.locked_pose if (self.locked and self.locked_pose is not None) else self.bottle
        fresh_ok = False
        if src is not None:
            age_ms = (self.get_clock().now().nanoseconds - self.bottle_time_ns) / 1e6
            fresh_ok = (age_ms <= self.fresh_ms) or self.locked

        # If no fresh pose, hold a safe posture
        if not fresh_ok:
            self.publish_jointctrl_rad([0.05, -0.60, 1.00, 0.00, 0.60, 0.00], self.grip_deg)
            return

        # Clamp workspace and apply reach offsets
        x = clamp(src.pose.position.x - self.reach_offset_x, self.min_x, self.max_x)
        y = clamp(src.pose.position.y, -self.y_lim, self.y_lim)
        z = clamp(src.pose.position.z + self.reach_offset_z, self.min_z, self.max_z)

        goal = self.goal_frame(x, y, z)
        q = self.ik_solve(goal)
        if q is None or len(q) < 6:
            self._warn_throttled("IK failed; holding pose", 1.0)
            return

        # Publish 6 DOF + gripper angleDeg
        self.publish_jointctrl_rad(q[:6], self.grip_deg)

    def publish_jointctrl_rad(self, q6_rad, grip_deg):
        qdeg = [rad2deg(v) for v in q6_rad]
        data = {
            "seq": 4, "address": 1, "funcode": 2,
            "data": {
                "mode": 1,
                "angle0": qdeg[0], "angle1": qdeg[1], "angle2": qdeg[2],
                "angle3": qdeg[3], "angle4": qdeg[4], "angle5": qdeg[5],
                "angle6": float(grip_deg)
            }
        }
        msg = ArmString()
        msg.data = json.dumps(data)
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = ArmBottleReacher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

