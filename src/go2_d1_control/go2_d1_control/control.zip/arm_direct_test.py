#!/usr/bin/env python3
import math, json, rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import Float64MultiArray
from unitree_arm.msg import ArmString

def rad2deg(x): return x*180.0/math.pi

class ArmDirectTest(Node):
    def __init__(self):
        super().__init__('arm_direct_test')
        self.declare_parameter('mode', 'unitree')  # 'unitree' or 'wbc'
        self.declare_parameter('q', [0, -0.6, 1.0, 0, 0.6, 0, 0])
        self.declare_parameter('rate_hz', 30.0)

        mode = self.get_parameter('mode').get_parameter_value().string_value
        q = self.get_parameter('q').get_parameter_value().double_array_value
        rate = self.get_parameter('rate_hz').get_parameter_value().double_value

        if mode == 'unitree':
            qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,
                             durability=DurabilityPolicy.VOLATILE,
                             history=HistoryPolicy.KEEP_LAST, depth=1)
            pub = self.create_publisher(ArmString, '/arm_Command', qos)
            deg = [rad2deg(v) for v in q]
            payload = {"seq":4,"address":1,"funcode":2,"data":{
                "id":-1,
                "angle0":deg[0],"angle1":deg[1],"angle2":deg[2],
                "angle3":deg[3],"angle4":deg[4],"angle5":deg[5],"angle6":deg[6]
            }}
            self.get_logger().info("Publishing JSON to /arm_Command (BEST_EFFORT depth=1)")
            def tick():
                m = ArmString(); m.data = json.dumps(payload, separators=(',',':')); pub.publish(m)
            self.timer = self.create_timer(1.0/max(1.0,rate), tick)

        else:
            qos = QoSProfile(reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.VOLATILE,
                             history=HistoryPolicy.KEEP_LAST, depth=10)
            pub = self.create_publisher(Float64MultiArray, '/wbc/arm_cmd', qos)
            self.get_logger().info("Publishing q to /wbc/arm_cmd (RELIABLE depth=10)")
            def tick():
                m = Float64MultiArray(); m.data = list(q); pub.publish(m)
            self.timer = self.create_timer(1.0/max(1.0,rate), tick)

def main():
    rclpy.init(); rclpy.spin(ArmDirectTest()); rclpy.shutdown()
if __name__ == '__main__': main()

