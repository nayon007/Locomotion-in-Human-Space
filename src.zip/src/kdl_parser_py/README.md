# KDL Parser

This contains a Python package for converting from URDF to a representation in KDL.

This was originally part of the [`ros/robot_model`](https://github.com/ros/robot_model) repository.
It has been moved to this repo as described by [`ros/robot_model#195`](https://github.com/ros/robot_model/issues/195)
